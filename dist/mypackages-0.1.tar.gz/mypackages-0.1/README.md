# Mypackage
This libruary was created as an example of how to publish my own Python package.
This package calculates and returns a subset of a sorted list

## How to install
...